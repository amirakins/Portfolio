package com.example.budget_buddy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
